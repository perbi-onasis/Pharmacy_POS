package com.PharmacyPOs.Pharmacy_POS.user_account;

public enum Role {
    ADMIN,
    SUB_ADMIN,
    SALES_AGENT,
    FINANCE_AGENT
}
