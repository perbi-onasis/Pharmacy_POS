package com.PharmacyPOs.Pharmacy_POS.user_account;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

@Controller
@RequestMapping
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public RedirectView registerUser(@RequestBody User user) {
        userService.registerUser(user);
        return new RedirectView("/dashboard");
    }

    @PostMapping("/login")
    public String loginUser(@RequestParam String username, @RequestParam String password, RedirectAttributes redirectAttributes) {
        User user = userService.getUserByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            // Authentication successful
            // Prepare data to be displayed on the dashboard
            String dashboardMessage = "Welcome, " + user.getUsername() + "!"; // Example message

            // Bind data to the redirect
            redirectAttributes.addFlashAttribute("dashboardMessage", dashboardMessage);

            // Redirect to the dashboard page
            return "redirect:/dashboard";
        } else {
            // Authentication failed
            // You might want to handle this case differently, e.g., redirect back to the login page with an error message
            return "redirect:/login?error";
        }
    }

    @GetMapping("/{username}")
    public ResponseEntity<User> getUserByUsername(@PathVariable String username) {
        User user = userService.getUserByUsername(username);
        if (user != null) {
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{username}")
    public ResponseEntity<String> updateUser(@PathVariable String username, @RequestBody User updatedUser) {
        userService.updateUser(username, updatedUser);
        return ResponseEntity.ok("User updated successfully");
    }

    @DeleteMapping("/{username}")
    public ResponseEntity<String> deleteUser(@PathVariable String username) {
        userService.deleteUser(username);
        return ResponseEntity.ok("User deleted successfully");
    }

    @GetMapping("/dashboard")
    public String showDashboard() {
        // Logic to retrieve dashboard data if needed
        return "dashboard"; // Assuming "dashboard" is the name of your HTML template for the dashboard
    }

    @GetMapping("/register")
    public String showRegister(Model model) {
        // Logic to retrieve dashboard data if needed
         model.addAttribute("user", new User());
         return "register"; // Assuming "dashboard" is the name of your HTML template for the dashboard
    }

    @GetMapping("/pos")
    public String showPOS() {
        return "pos"; // Assuming "pos" is the name of your HTML template for the POS page
    }

    @GetMapping("/stocks")
    public String showStocks() {
        return "stocks"; // Assuming "stocks" is the name of your HTML template for the stocks page
    }

    @GetMapping("/settings")
    public String showSettings() {
        return "settings"; // Assuming "settings" is the name of your HTML template for the settings page
    }
}
